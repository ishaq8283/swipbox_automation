package base_quit;

import org.testng.annotations.AfterSuite;

import base_package.Page;

public class BaseQuit extends Page

{
	@AfterSuite
	public void tearDown ()
	{
		
		driver.quit();
	}

}
